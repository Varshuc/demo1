package com.cource_management_app.cource_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourceAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CourceAppApplication.class, args);
	}

}
