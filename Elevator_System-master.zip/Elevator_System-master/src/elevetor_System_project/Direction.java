package elevetor_System_project;

public enum Direction {
	 UP,
	 DOWN,
	 IDLE
	}

